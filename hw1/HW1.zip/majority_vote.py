import sys
import numpy as np
from collections import Counter

def majority_vote_classifier(train_input, test_input, train_out, test_out, metrics_out):
    # Load data
    train_data = np.genfromtxt(train_input, delimiter='\t', names=True, dtype=None, encoding=None)
    test_data = np.genfromtxt(test_input, delimiter='\t', names=True, dtype=None, encoding=None)
    
    # Step 1: Define the most common label in the train data
    target_column = train_data.dtype.names[-1]
    
    train_labels = train_data[target_column]
    test_labels = test_data[target_column]
        
    label_counts = Counter(train_labels)
    most_common_label = max(label_counts, key=lambda x: (label_counts[x], x))

    # Step 2: Make predictions
    train_predict = np.full(len(train_data), most_common_label)
    test_predict = np.full(len(test_data), most_common_label)
    
    # Write predictions to files
    np.savetxt(train_out, train_predict, fmt='%s', newline='\n')
    np.savetxt(test_out, test_predict, fmt='%s', newline='\n')
    
    # Step 3: Calculate error rates
    train_errors = np.sum(train_predict != train_labels)
    test_errors = np.sum(test_predict != test_labels)
    
    train_error_rate = train_errors / len(train_labels)
    test_error_rate = test_errors / len(test_labels)
    
    # Write metrics to file
    with open(metrics_out, 'w') as f:
        f.write(f"error(train): {train_error_rate:.6f}\n")
        f.write(f"error(test): {test_error_rate:.6f}\n")

if __name__ == '__main__':
    if len(sys.argv) != 6:
        print("Usage: python script.py <train_input> <test_input> <train_out> <test_out> <metrics_out>")
        sys.exit(1)

    train_input = sys.argv[1]
    test_input = sys.argv[2]
    train_out = sys.argv[3]
    test_out = sys.argv[4]
    metrics_out = sys.argv[5]

    majority_vote_classifier(train_input, test_input, train_out, test_out, metrics_out)
    print('File output successfully')